/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CapaDomini;


public class GrauMinim{
    public int id1;
    public int id2;
    public int grau;
    
}
